﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class OrderItem : IEquatable<OrderItem>
    {
        public Int64 OrderId { get; set; }
        public string OrderName  { get; set; }
        public string RefId { get; set; }
        public bool Equals(OrderItem objOrders)
        {
            return (this.OrderId,this.OrderName,this.RefId)==
                (objOrders.OrderId,objOrders.OrderName,objOrders.RefId);
        }

    }
}
